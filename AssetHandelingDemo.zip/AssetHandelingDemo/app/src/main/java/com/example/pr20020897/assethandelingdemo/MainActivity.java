package com.example.pr20020897.assethandelingdemo;

import android.content.res.AssetFileDescriptor;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    TextView text;
    ImageView imageView;
    Button textbtn, image, audio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = findViewById(R.id.text);
        imageView = findViewById(R.id.image);
        textbtn = findViewById(R.id.txt_btn);
        image = findViewById(R.id.image_btn);
        audio = findViewById(R.id.audio_btn);

        textbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readTextFile();
            }
        });
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setImage();
            }
        });
        audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playAudio();
            }
        });

    }

    private void playAudio() {

        MediaPlayer player = new MediaPlayer();
        try {
            AssetFileDescriptor assetFileDescriptor = getAssets().openFd("im_impressed.mp3");
            player.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
            player.prepare();
            player.start();
        } catch (IOException e) {
            Toast.makeText(this, "Mp3 file not found !", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }


    private void setImage() {
        try {
            InputStream is = getAssets().open("download.png");
            Drawable d = Drawable.createFromStream(is, null);
            imageView.setImageDrawable(d);
            is.close();
        } catch (IOException ex) {
            Toast.makeText(this, "Image not found !", Toast.LENGTH_SHORT).show();
            ex.printStackTrace();
        }
    }

    private void readTextFile() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(
                    new InputStreamReader(getAssets().open("test.txt"), "UTF-8"));

            String mLine;
            text.setText("");
            while ((mLine = reader.readLine()) != null) {
                text.append(String.format("%s ", mLine));
            }
        } catch (IOException e) {
            Toast.makeText(this, "File not found !", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
